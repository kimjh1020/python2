print("=" * 50)
print("My Program")
print("=" * 50)